AVI JET ANALYZER — GOLD EDITION (Android Studio project)

This is Android project source, not a compiled APK. It wraps the offline HTML analyzer in an Android WebView and supports selecting an image screenshot.

Build APK:
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle sync and install the required Android SDK (compile SDK 35).
4. Select Build > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

Prototype limitations:
- Screenshot is previewed only. Automatic OCR (reading multiplier text from the image) is not implemented.
- It does not connect to 1win.
- It cannot reliably predict the next Avi Jet result; previous multipliers do not reveal the next one.
- No betting or account credentials are collected.
